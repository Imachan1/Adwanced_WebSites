async function request(path, options) {
  const response = await fetch(path, options);

  if (!response.ok) {
    throw new Error('Blad polaczenia z API.');
  }

  return response.json();
}

export function getReaders() {
  return request('/api/readers');
}

export function getLoansByReader(readerId) {
  return request(`/api/loans/${readerId}`);
}

export function getAuthors() {
  return request('/api/authors');
}

export function createAuthor(payload) {
  return request('/api/authors', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });
}

export function getBooks() {
  return request('/api/books');
}

export function createBook(payload) {
  return request('/api/books', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });
}
