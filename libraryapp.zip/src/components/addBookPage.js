import { useEffect, useState } from 'react';
import AppLayout from './appLayout';
import { createBook, getAuthors } from '../services/libraryApi';

function AddBookPage() {
  const [authors, setAuthors] = useState([]);
  const [title, setTitle] = useState('');
  const [authorId, setAuthorId] = useState('');
  const [price, setPrice] = useState('');
  const [purchaseDate, setPurchaseDate] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  useEffect(() => {
    async function loadAuthors() {
      try {
        setError('');
        const data = await getAuthors();
        setAuthors(data);
      } catch (err) {
        setError('Nie udalo sie pobrac listy autorow.');
      }
    }

    loadAuthors();
  }, []);

  async function onSubmit(event) {
    event.preventDefault();

    try {
      setError('');
      setMessage('');

      await createBook({
        title,
        authorId: Number(authorId),
        price: Number(price),
        purchaseDate
      });

      setMessage('Ksiazka zostala dodana.');
      setTitle('');
      setAuthorId('');
      setPrice('');
      setPurchaseDate('');
    } catch (err) {
      setError('Nie udalo sie dodac ksiazki.');
    }
  }

  return (
    <AppLayout>
      <div className="pagebox pagecontent">
        <h4>Wstaw ksiazke</h4>
        <form className="formgrid" onSubmit={onSubmit}>
          <label htmlFor="bookTitle">Tytul</label>
          <input id="bookTitle" value={title} onChange={(e) => setTitle(e.target.value)} required />

          <label htmlFor="bookAuthor">Autor</label>
          <select
            id="bookAuthor"
            value={authorId}
            onChange={(e) => setAuthorId(e.target.value)}
            required
          >
            <option value="">Wybierz autora</option>
            {authors.map((author) => (
              <option key={author.id} value={author.id}>
                {author.fullName}
              </option>
            ))}
          </select>

          <label htmlFor="bookPrice">Cena</label>
          <input
            id="bookPrice"
            type="number"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            required
          />

          <label htmlFor="bookDate">Data zakupu</label>
          <input
            id="bookDate"
            type="date"
            value={purchaseDate}
            onChange={(e) => setPurchaseDate(e.target.value)}
            required
          />

          <button type="submit">Dodaj ksiazke</button>
        </form>

        {message ? <p className="success">{message}</p> : null}
        {error ? <p className="error">{error}</p> : null}
      </div>
    </AppLayout>
  );
}

export default AddBookPage;
