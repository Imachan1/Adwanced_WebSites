import Header from './header';

function AppLayout({ children }) {
  return (
    <div>
      <div className="container">
        <Header title="Biblioteka Miejska" />
      </div>
      <div className="container">{children}</div>
    </div>
  );
}

export default AppLayout;
