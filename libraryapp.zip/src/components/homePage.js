import Body from './body';
import AppLayout from './appLayout';

function HomePage() {
  return (
    <AppLayout>
      <Body />
    </AppLayout>
  );
}

export default HomePage;
