import { useEffect, useState } from 'react';
import AppLayout from './appLayout';
import { getBooks } from '../services/libraryApi';

function BooksPage() {
  const [books, setBooks] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    async function load() {
      try {
        setError('');
        const data = await getBooks();
        setBooks(data);
      } catch (err) {
        setError('Nie udalo sie pobrac ksiazek.');
      }
    }

    load();
  }, []);

  return (
    <AppLayout>
      <div className="pagebox pagecontent">
        <h4>Lista ksiazek</h4>
        {error ? <p className="error">{error}</p> : null}
        <table className="datatable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Tytul</th>
              <th>Autor</th>
              <th>Cena</th>
            </tr>
          </thead>
          <tbody>
            {books.map((book) => (
              <tr key={book.id}>
                <td>{book.id}</td>
                <td>{book.title}</td>
                <td>{book.authorName}</td>
                <td>{book.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppLayout>
  );
}

export default BooksPage;
