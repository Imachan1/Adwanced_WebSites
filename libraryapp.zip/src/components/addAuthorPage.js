import { useState } from 'react';
import AppLayout from './appLayout';
import { createAuthor } from '../services/libraryApi';

function AddAuthorPage() {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  async function onSubmit(event) {
    event.preventDefault();

    try {
      setError('');
      setMessage('');

      await createAuthor({ firstName, lastName });
      setMessage('Autor zostal dodany.');
      setFirstName('');
      setLastName('');
    } catch (err) {
      setError('Nie udalo sie dodac autora.');
    }
  }

  return (
    <AppLayout>
      <div className="pagebox pagecontent">
        <h4>Wstaw autora</h4>
        <form className="formgrid" onSubmit={onSubmit}>
          <label htmlFor="authorFirstName">Imie</label>
          <input
            id="authorFirstName"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            required
          />

          <label htmlFor="authorLastName">Nazwisko</label>
          <input
            id="authorLastName"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />

          <button type="submit">Dodaj autora</button>
        </form>

        {message ? <p className="success">{message}</p> : null}
        {error ? <p className="error">{error}</p> : null}
      </div>
    </AppLayout>
  );
}

export default AddAuthorPage;
