import { useState } from 'react';
import AppLayout from './appLayout';
import { getLoansByReader } from '../services/libraryApi';

function ReaderLoansPage() {
  const [readerId, setReaderId] = useState('');
  const [loans, setLoans] = useState([]);
  const [error, setError] = useState('');

  async function onSubmit(event) {
    event.preventDefault();

    try {
      setError('');
      const data = await getLoansByReader(readerId);
      setLoans(data);
    } catch (err) {
      setError('Nie udalo sie pobrac wypozyczen.');
      setLoans([]);
    }
  }

  return (
    <AppLayout>
      <div className="pagebox pagecontent">
        <h4>Sprawdzanie wypozyczen czytelnika</h4>
        <form className="formgrid" onSubmit={onSubmit}>
          <label htmlFor="readerId">ID czytelnika</label>
          <input
            id="readerId"
            value={readerId}
            onChange={(e) => setReaderId(e.target.value)}
            placeholder="np. 1"
            required
          />
          <button type="submit">Sprawdz</button>
        </form>

        {error ? <p className="error">{error}</p> : null}

        <table className="datatable">
          <thead>
            <tr>
              <th>ID ksiazki</th>
              <th>Tytul</th>
            </tr>
          </thead>
          <tbody>
            {loans.map((loan, index) => (
              <tr key={`${loan.bookId}-${index}`}>
                <td>{loan.bookId}</td>
                <td>{loan.bookTitle}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppLayout>
  );
}

export default ReaderLoansPage;
