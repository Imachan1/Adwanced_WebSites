function Body() {
  return (
    <div>   

        <h4>Strona Startowa</h4>

        <div className="containerbody">
            <div>
                <h3>Czytelnicy</h3>

                <div className="vertical">
                    <button>Lista czytelników</button>
                    <button>Sprawdzanie wypożyczeń czytelnika</button>
                </div>
            </div>

            <div>
                <h3>Wstawianie danych</h3>

                <div className="vertical">
                    <button>Wstaw autora</button>
                    <button>Wstaw książkę</button>
                </div>
            </div>
            
            <div>
                <h3>Sprawdzanie danych</h3>

                <div className="vertical">
                    <button>Lista autorów</button>
                    <button>Lista książek</button>
                </div>
            </div>
            
        </div>
    </div>
  );
}

export default Body;