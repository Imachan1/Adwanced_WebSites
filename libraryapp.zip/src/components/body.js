import { Link } from 'react-router-dom';

function Body() {
  return (
    <div>   

        <h4>Strona Startowa</h4>

        <div className="containerbody">
            <div>
                <h3>Czytelnicy</h3>

                <div className="vertical">
                    <Link className="navbutton" to="/czytelnicy">Lista czytelnikow</Link>
                    <Link className="navbutton" to="/wypozyczenia">Sprawdzanie wypozyczen czytelnika</Link>
                </div>
            </div>

            <div>
                <h3>Wstawianie danych</h3>

                <div className="vertical">
                    <Link className="navbutton" to="/autor/dodaj">Wstaw autora</Link>
                    <Link className="navbutton" to="/ksiazka/dodaj">Wstaw ksiazke</Link>
                </div>
            </div>
            
            <div>
                <h3>Sprawdzanie danych</h3>

                <div className="vertical">
                    <Link className="navbutton" to="/autorzy">Lista autorow</Link>
                    <Link className="navbutton" to="/ksiazki">Lista ksiazek</Link>
                </div>
            </div>
            
        </div>
    </div>
  );
}

export default Body;