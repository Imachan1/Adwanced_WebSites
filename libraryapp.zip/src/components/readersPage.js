import { useEffect, useState } from 'react';
import AppLayout from './appLayout';
import { getReaders } from '../services/libraryApi';

function ReadersPage() {
  const [readers, setReaders] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    async function load() {
      try {
        setError('');
        const data = await getReaders();
        setReaders(data);
      } catch (err) {
        setError('Nie udalo sie pobrac czytelnikow.');
      }
    }

    load();
  }, []);

  return (
    <AppLayout>
      <div className="pagebox pagecontent">
        <h4>Lista czytelnikow</h4>
        {error ? <p className="error">{error}</p> : null}
        <table className="datatable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Imie</th>
              <th>Nazwisko</th>
            </tr>
          </thead>
          <tbody>
            {readers.map((reader) => (
              <tr key={reader.id}>
                <td>{reader.id}</td>
                <td>{reader.firstName}</td>
                <td>{reader.lastName}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppLayout>
  );
}

export default ReadersPage;
