import { useEffect, useState } from 'react';
import AppLayout from './appLayout';
import { getAuthors } from '../services/libraryApi';

function AuthorsPage() {
  const [authors, setAuthors] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    async function load() {
      try {
        setError('');
        const data = await getAuthors();
        setAuthors(data);
      } catch (err) {
        setError('Nie udalo sie pobrac autorow.');
      }
    }

    load();
  }, []);

  return (
    <AppLayout>
      <div className="pagebox pagecontent">
        <h4>Lista autorow</h4>
        {error ? <p className="error">{error}</p> : null}
        <table className="datatable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Imie</th>
              <th>Nazwisko</th>
            </tr>
          </thead>
          <tbody>
            {authors.map((author) => (
              <tr key={author.id}>
                <td>{author.id}</td>
                <td>{author.firstName}</td>
                <td>{author.lastName}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </AppLayout>
  );
}

export default AuthorsPage;
