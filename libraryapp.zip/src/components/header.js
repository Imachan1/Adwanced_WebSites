function Header(props) {
    return (
        <header>
            <img src="../img/library.jpg" width="600" height="250" style={{ opacity: 0.8, marginTop: '40px' }} />
            <h1>Witamy w systemie obsługi bibliotek</h1>
            <h2>Biblioteka: {props.title}</h2>
        </header>
    );
}

export default Header;