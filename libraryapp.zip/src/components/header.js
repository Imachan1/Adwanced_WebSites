import { Link } from 'react-router-dom';

function Header(props) {
    return (
        <header>
            <img src="/img/library.jpg" alt="Wnetrze biblioteki" width="600" height="250" style={{ opacity: 0.8, marginTop: '40px' }} />
            <h1>Witamy w systemie obsługi bibliotek</h1>
            <h2>Biblioteka: {props.title}</h2>
            <Link className="homebutton" to="/">Strona główna</Link>
        </header>
    );
}

export default Header;