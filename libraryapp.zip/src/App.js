import logo from './logo.svg';
import './App.css';
import Header from './components/header';
import Body from './components/body';

function App() {
  return (
    <div>
      <div className="container">
        <Header title="Biblioteka Miejska" />
      </div>
      <div className="container">
        <Body />
      </div>
    </div>
  );
}

export default App;
