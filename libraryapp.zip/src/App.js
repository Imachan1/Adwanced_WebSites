import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import HomePage from './components/homePage';
import ReadersPage from './components/readersPage';
import ReaderLoansPage from './components/readerLoansPage';
import AddAuthorPage from './components/addAuthorPage';
import AddBookPage from './components/addBookPage';
import AuthorsPage from './components/authorsPage';
import BooksPage from './components/booksPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/czytelnicy" element={<ReadersPage />} />
        <Route path="/wypozyczenia" element={<ReaderLoansPage />} />
        <Route path="/autor/dodaj" element={<AddAuthorPage />} />
        <Route path="/ksiazka/dodaj" element={<AddBookPage />} />
        <Route path="/autorzy" element={<AuthorsPage />} />
        <Route path="/ksiazki" element={<BooksPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
