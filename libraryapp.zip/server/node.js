const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
require('dotenv').config();

const app = express();

app.use(cors());
app.use(express.json());
const pool = mysql.createPool({
  host: process.env.DB_HOST || '127.0.0.1',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'library',
  waitForConnections: true,
  connectionLimit: 10
});

const schemaCache = {};

async function getColumns(tableName) {
  if (schemaCache[tableName]) {
    return schemaCache[tableName];
  }

  const [rows] = await pool.query(`SHOW COLUMNS FROM ${tableName}`);
  const columns = rows.map((row) => row.Field);
  schemaCache[tableName] = columns;
  return columns;
}

function pickColumn(columns, candidates) {
  const normalized = columns.map((col) => ({ original: col, lower: col.toLowerCase() }));

  for (const candidate of candidates) {
    const found = normalized.find((col) => col.lower === candidate.toLowerCase());
    if (found) {
      return found.original;
    }
  }

  for (const candidate of candidates) {
    const found = normalized.find((col) => col.lower.includes(candidate.toLowerCase()));
    if (found) {
      return found.original;
    }
  }

  return null;
}

async function resolveSchema() {
  const authorColumns = await getColumns('autorzy');
  const readerColumns = await getColumns('czytelnicy');
  const bookColumns = await getColumns('ksiazki');
  const loanColumns = await getColumns('wypozyczenia');

  return {
    authors: {
      table: 'autorzy',
      id: pickColumn(authorColumns, ['idautor', 'id_autor', 'id']),
      firstName: pickColumn(authorColumns, ['imie', 'first_name', 'name']),
      lastName: pickColumn(authorColumns, ['nazwisko', 'last_name', 'surname'])
    },
    readers: {
      table: 'czytelnicy',
      id: pickColumn(readerColumns, ['idczytelnik', 'id_czytelnik', 'id']),
      firstName: pickColumn(readerColumns, ['czytimie', 'imie', 'first_name', 'name']),
      lastName: pickColumn(readerColumns, ['czytnazwisko', 'nazwisko', 'last_name', 'surname'])
    },
    books: {
      table: 'ksiazki',
      id: pickColumn(bookColumns, ['idksiazka', 'id_ksiazka', 'idksiazki', 'id']),
      title: pickColumn(bookColumns, ['tytul', 'nazwa', 'title']),
      authorId: pickColumn(bookColumns, ['autor', 'idautor', 'author_id']),
      price: pickColumn(bookColumns, ['cena', 'price']),
      purchaseDate: pickColumn(bookColumns, ['datazakupu', 'data_zakupu', 'purchased_at'])
    },
    loans: {
      table: 'wypozyczenia',
      id: pickColumn(loanColumns, ['idwypozyczenie', 'id_wypozyczenie', 'id']),
      readerId: pickColumn(loanColumns, ['czytelnik', 'idczytelnik', 'reader_id']),
      bookId: pickColumn(loanColumns, ['ksiazka', 'idksiazka', 'book_id']),
      borrowDate: pickColumn(loanColumns, ['datawypozyczenia', 'data_wypozyczenia', 'borrowed_at']),
      returnDate: pickColumn(loanColumns, ['datazwrotu', 'data_zwrotu', 'returned_at'])
    }
  };
}

function requireFields(values, fields) {
  for (const field of fields) {
    if (!values[field]) {
      return field;
    }
  }
  return null;
}

function sendServerError(res, error) {
  console.error(error);
  res.status(500).json({ error: 'Blad serwera.' });
}

app.get('/api/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', database: 'connected' });
  } catch (error) {
    sendServerError(res, error);
  }
});

app.get('/api/readers', async (req, res) => {
  try {
    const schema = await resolveSchema();
    const [rows] = await pool.query(
      `SELECT ${schema.readers.id} AS id, ${schema.readers.firstName} AS firstName, ${schema.readers.lastName} AS lastName FROM ${schema.readers.table} ORDER BY ${schema.readers.id}`
    );

    const mapped = rows.map((row) => ({
      id: row.id,
      firstName: row.firstName,
      lastName: row.lastName,
      fullName: `${row.firstName || ''} ${row.lastName || ''}`.trim()
    }));

    res.json(mapped);
  } catch (error) {
    sendServerError(res, error);
  }
});

app.get('/api/loans/:readerId', async (req, res) => {
  try {
    const schema = await resolveSchema();
    const readerId = Number(req.params.readerId);

    if (!readerId) {
      return res.status(400).json({ error: 'Nieprawidlowe readerId.' });
    }

    const selectParts = [
      `l.${schema.loans.readerId} AS readerId`,
      `l.${schema.loans.bookId} AS bookId`,
      `b.${schema.books.title} AS bookTitle`
    ];

    if (schema.loans.id) {
      selectParts.unshift(`l.${schema.loans.id} AS id`);
    }
    if (schema.loans.borrowDate) {
      selectParts.push(`l.${schema.loans.borrowDate} AS borrowDate`);
    }
    if (schema.loans.returnDate) {
      selectParts.push(`l.${schema.loans.returnDate} AS returnDate`);
    }

    const orderBy = schema.loans.id ? `l.${schema.loans.id} DESC` : `l.${schema.loans.bookId} DESC`;
    const sql = `
      SELECT ${selectParts.join(', ')}
      FROM ${schema.loans.table} l
      LEFT JOIN ${schema.books.table} b ON b.${schema.books.id} = l.${schema.loans.bookId}
      WHERE l.${schema.loans.readerId} = ?
      ORDER BY ${orderBy}
    `;

    const [rows] = await pool.query(sql, [readerId]);
    res.json(rows);
  } catch (error) {
    sendServerError(res, error);
  }
});

app.get('/api/authors', async (req, res) => {
  try {
    const schema = await resolveSchema();
    const [rows] = await pool.query(
      `SELECT ${schema.authors.id} AS id, ${schema.authors.firstName} AS firstName, ${schema.authors.lastName} AS lastName FROM ${schema.authors.table} ORDER BY ${schema.authors.id}`
    );

    const mapped = rows.map((row) => ({
      id: row.id,
      firstName: row.firstName,
      lastName: row.lastName,
      fullName: `${row.firstName || ''} ${row.lastName || ''}`.trim()
    }));

    res.json(mapped);
  } catch (error) {
    sendServerError(res, error);
  }
});

app.post('/api/authors', async (req, res) => {
  try {
    const schema = await resolveSchema();
    const firstName = req.body.firstName || req.body.imie || req.body.name;
    const lastName = req.body.lastName || req.body.nazwisko || '';

    const missing = requireFields({ firstName }, ['firstName']);
    if (missing) {
      return res.status(400).json({ error: 'Pole imie/firstName jest wymagane.' });
    }

    const sql = `INSERT INTO ${schema.authors.table} (${schema.authors.firstName}, ${schema.authors.lastName}) VALUES (?, ?)`;
    const [result] = await pool.query(sql, [firstName, lastName]);

    res.status(201).json({ id: result.insertId, firstName, lastName });
  } catch (error) {
    sendServerError(res, error);
  }
});

app.get('/api/books', async (req, res) => {
  try {
    const schema = await resolveSchema();

    const sql = `
      SELECT
        b.${schema.books.id} AS id,
        b.${schema.books.title} AS title,
        b.${schema.books.authorId} AS authorId,
        b.${schema.books.price} AS price,
        b.${schema.books.purchaseDate} AS purchaseDate,
        a.${schema.authors.firstName} AS authorFirstName,
        a.${schema.authors.lastName} AS authorLastName
      FROM ${schema.books.table} b
      LEFT JOIN ${schema.authors.table} a ON a.${schema.authors.id} = b.${schema.books.authorId}
      ORDER BY b.${schema.books.id} DESC
    `;

    const [rows] = await pool.query(sql);
    const mapped = rows.map((row) => ({
      id: row.id,
      title: row.title,
      authorId: row.authorId,
      price: row.price,
      purchaseDate: row.purchaseDate,
      authorName: `${row.authorFirstName || ''} ${row.authorLastName || ''}`.trim()
    }));

    res.json(mapped);
  } catch (error) {
    sendServerError(res, error);
  }
});

app.post('/api/books', async (req, res) => {
  try {
    const schema = await resolveSchema();
    const title = req.body.title || req.body.tytul;
    const authorId = Number(req.body.authorId || req.body.autor);
    const price = req.body.price || req.body.cena || null;
    const purchaseDate = req.body.purchaseDate || req.body.dataZakupu || null;

    const missing = requireFields({ title, authorId }, ['title', 'authorId']);
    if (missing) {
      return res.status(400).json({ error: 'Pola title i authorId sa wymagane.' });
    }

    const [authorRows] = await pool.query(
      `SELECT ${schema.authors.id} AS id FROM ${schema.authors.table} WHERE ${schema.authors.id} = ? LIMIT 1`,
      [authorId]
    );
    if (!authorRows.length) {
      return res.status(404).json({ error: 'Nie znaleziono autora.' });
    }

    const sql = `
      INSERT INTO ${schema.books.table} (${schema.books.title}, ${schema.books.authorId}, ${schema.books.price}, ${schema.books.purchaseDate})
      VALUES (?, ?, ?, ?)
    `;
    const [result] = await pool.query(sql, [title, authorId, price, purchaseDate]);

    res.status(201).json({
      id: result.insertId,
      title,
      authorId,
      price,
      purchaseDate
    });
  } catch (error) {
    sendServerError(res, error);
  }
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
