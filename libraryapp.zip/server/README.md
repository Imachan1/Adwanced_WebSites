# Node.js backend (Express)

Backend jest w jednym pliku: node.js

## Database config

Skopiuj `.env.example` do `.env` i ustaw dane MySQL.

## Install

npm install

## Run (development)

npm run dev

## Run (production style)

npm start

## Default URL

http://localhost:5000

## Endpoints

- GET /api/health
- GET /api/readers
- GET /api/loans/:readerId
- GET /api/authors
- POST /api/authors
- GET /api/books
- POST /api/books
