import logo from './logo.svg';
import './App.css';
import Main from './Main';
import Footer from './Footer';
import Header from './Header';

function App() {
  return (
    <div>
      <div id="srodek">
        <Header title="Polecamy buty firmy: Moje Obuwie" />
      </div>
      <Main />
      <div id="srodek">
        <Footer />
      </div>
    </div>
  );
}

export default App;
