import { useState } from "react";

const ObuwiePoczatkowe = [
    {id: 1, typ: "letnie", rodzaj: "sandały", stanMagazynu: 10, img: "../images/1.png" },
    {id: 2, typ: "letnie", rodzaj: "klapki", stanMagazynu: 0, img: "../images/2.jpg" },
    {id: 5, typ: "letnie", rodzaj: "japonki", stanMagazynu: 10, img: "../images/4.jpg" },
]

function Main() {
    const [Obuwie, setObuwie] = useState(ObuwiePoczatkowe);

    const [visibleCategories, setVisibleCategories] = useState(["letnie"]);

    function handlerClickLetnie() {
        const obuwieZDodatkowymi = Obuwie.some(o => o.id === 6) ? Obuwie : [
            ...Obuwie,
            {id: 6, typ: "letnie", rodzaj: "drewniaki", stanMagazynu: 9, img: "../images/3.jpg" },
            {id: 7, typ: "letnie", rodzaj: "rzymianki", stanMagazynu: 8, img: "../images/5.jpg" },
        ];
        setObuwie(obuwieZDodatkowymi);
        
        setVisibleCategories((prev) => prev.includes("letnie") ? prev : [...prev, "letnie"]);
    }

    const handlerClickZimowe = () => {
        const obuwieZDodatkowymi = Obuwie.some(o => o.id === 3) ? Obuwie : [
            ...Obuwie,
            {id: 3, typ: "zimowe", rodzaj: "kozaki", stanMagazynu: 4,img: "../images/6.jpg" },
            {id: 4, typ: "zimowe", rodzaj: "trapry", stanMagazynu: 1, img: "../images/7.jpg" },
        ];
        setObuwie(obuwieZDodatkowymi);
        
        setVisibleCategories((prev) => prev.includes("zimowe") ? prev : [...prev, "zimowe"]);
    }

    const handlerClickWyprzedane = () => {
        const updatedObuwie = Obuwie.filter((item) => item.stanMagazynu > 0);
        setObuwie(updatedObuwie);
    }
    const handlerClickSprzedaz = (id) => {
        const updatedObuwie = Obuwie.map((item) => 
            item.id === id && item.stanMagazynu > 0 
                ? { ...item, stanMagazynu: item.stanMagazynu - 1 }
                : item
        );
        setObuwie(updatedObuwie);
    }

    const handlerClickPrzyjecie = (id) => {
        const input = window.prompt("Ile sztuk chcesz przyjąć?");
        const kwota = parseInt(input);
        if(isNaN(kwota) || kwota <= 0) {
            window.alert("Podaj poprawną dodatnią liczbę");
            return;
        }
        
        const updatedObuwie = Obuwie.map((item) => 
            item.id === id 
                ? { ...item, stanMagazynu: item.stanMagazynu + kwota }
                : item
        );
        setObuwie(updatedObuwie);
    }

    return (
        <main>
            <div class="cialo">

            
            <div id="srodek">
                <button id="btn" onClick={handlerClickLetnie}>Przyjmij obuwie letnie</button>
                <button id="btn" onClick={handlerClickZimowe}>Przyjmij obuwie zimowe</button>
                <button id="btn" onClick={handlerClickWyprzedane}>Usuń wyprzedane</button>
            </div>

            <div className="oferta-block">
                <div id="srodek"><h1>Nasza oferta:</h1></div>

                {visibleCategories.map((kategoria, index) => (
                    <div key={index}>
                        <div id="srodek">
                            <h2>Obuwie {kategoria}</h2>
                        </div>
                        {Obuwie.filter((o) => o.typ === kategoria).map((item) => (
                            <div key={item.id}>
                                <div class="container">
                                    <img src={item.img}/>
                                    <div class="container1">
                                        <div>
                                            <p><b><h1>Rodzaj: {item.rodzaj}</h1></b></p> 
                                            <h4>Stan magazynu: {item.stanMagazynu}</h4>
                                        </div>
                                        <div className="buttons-block">
                                        <button id="btn" onClick={() => handlerClickSprzedaz(item.id)} disabled={item.stanMagazynu === 0}>Sprzedaż detaliczna</button>
                                        <button id="btn" onClick={() => handlerClickPrzyjecie(item.id)}>Przyjęcie tych butów</button>
                                        </div>
                                    </div>
                                    <div>
                                </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ))}

            </div>
            </div>
        </main>
    );
}

export default Main;