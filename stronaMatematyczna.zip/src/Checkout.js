import React from "react";
import MyInput from "./MyInput";
import Header from "./Header";

function Checkout(){
    const [daneOsobowe, setDaneOsobowe] = React.useState({
        imie: "",
        nazwisko: "",
    });

    const changeHandler = event =>{
        let inpuValue = event.target.value;
        let inputName = event.target.name;
        setDaneOsobowe(prevState => ({
            ...prevState,
            [inputName]: inpuValue
        }));
    };

    return(
        <div>
            <div id="headcontainer">
                <Header title="Witamy na stronie: Matematyka dla każdego"/>
                <Header title="Pomożemy zrozumiec i rozwiązać: Równania kwadratowe"/>
            </div>

            <div class="bodycontainer">
                
                <br/><p>{"Postać ogólna:"}</p>
                <br/><p>{"ax^2 + bx + c = 0"}</p>
                <br/><p>{"wyróżnik równania kwadratowego"}</p>
                <br/><p>{"delta = b^2 - 4ac"}</p>
                <br/><p>{"jesli delta > 0 to równanie ma dwa rozwiązania:"}</p>
                <br/><p>{"x1 = (-b - √delta) / 2a"}</p>
                <br/><p>{"x2 = (-b + √delta) / 2a"}</p>
                <br/><p>{"jesli delta = 0 to równanie ma jedno rozwiązanie:"}</p>
                <br/><p>{"x = -b / 2a"}</p>
                <br/><p>{"jesli delta < 0 to równanie nie ma rozwiazania"}</p>
                
            </div>
            
            <form>
                <div id="container">
                    <div class="resultcontainer">
                        <p>Przykladowe obliczenia</p>

                <MyInput
                    type="number"
                    name="a"
                    label="Proszę podać A:"
                    className="form-control"
                    value={daneOsobowe.a}
                    onChange={changeHandler}
                />

                <MyInput
                    type="number"
                    name="b"
                    label="Proszę podać B:"
                    className="form-control"
                    value={daneOsobowe.b}
                    onChange={changeHandler}
                />

                <MyInput
                    type="number"
                    name="c"
                    label="Proszę podać C:"
                    className="form-control"
                    value={daneOsobowe.c}
                    onChange={changeHandler}
                />

                        <p>Rownanie o postaci:</p>

                        <br/> {(daneOsobowe.a==="")?"brak":daneOsobowe.a} x^2 + 
                        {(daneOsobowe.b==="")?"brak":daneOsobowe.b} x + 
                        {(daneOsobowe.c==="")?"brak":daneOsobowe.c} = 0

                    </div>

                    <div class="imgcontainer">

                    </div>

                </div>
            </form>
        </div>
    );
}

export default Checkout;