import { useState } from "react";

function EmailInput(){
    const [errorMessage, setErrorMessage] = useState("");
    function evaluateEmail(event){
        const enteredEmail = event.target.value;
        alert("funkcja");
        if(enteredEmail.trim() === "" || !enteredEmail.includes("@")){
            setErrorMessage("Please enter a valid email address.");
        }
        else{
            setErrorMessage("Okay");
        }
    };
    return(
        <div>
            <h5>Wejsciowka</h5>
            <input placeholder="user@skrzynka" type="email" onBlur={evaluateEmail}/>
            <p>{errorMessage}</p>
        </div>
    );
}

export default EmailInput;