import React from "react";
import {Row, Col, Container} from "react-bootstrap";
import MyInput from "./MyInput";

function Checkout(){
    const [daneOsobowe, setDaneOsobowe] = React.useState({
        imie: "",
        nazwisko: "",
    });

    const changeHandler = event =>{
        let inpuValue = event.target.value;
        let inputName = event.target.name;
        setDaneOsobowe(prevState => ({
            ...prevState,
            [inputName]: inpuValue
        }));
    };

    return(
        <Container>
            <form>
                <Row>
                    <Col xs={12}>
                        <h1>Witamy przy kasie</h1>
                        <h2>Prosze podac dane do wysylki: </h2>
                    </Col>
                </Row>
                <Row>
                    <Col xs={12} md={4} >
                        <MyInput
                            type="text"
                            name="imie"
                            label="Imie"
                            className="form-control"
                            value={daneOsobowe.imie}
                            onChange={changeHandler}
                        />
                    </Col>
                    <Col xs={12} md={4} >
                        <MyInput
                            type="text"
                            name="nazwisko"
                            label="Nazwisko"
                            className="form-control"
                            value={daneOsobowe.nazwisko}
                            onChange={changeHandler}
                        />
                    </Col>
                </Row>
                <br/>Wprowadzone imie: {(daneOsobowe.imie==="")?"brak":daneOsobowe.imie}
                <br/>Wprowadzone nazwisko: {(daneOsobowe.nazwisko==="")?"brak":daneOsobowe.nazwisko} 
            </form>
        </Container>
    );
}

export default Checkout;