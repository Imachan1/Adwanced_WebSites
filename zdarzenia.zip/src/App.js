import logo from './logo.svg';
import './App.css';
import EmailInput from './EmailInput';
import Checkout from './Checkout';

function App() {
  return (
    <div className="App">
      <Checkout />
    </div>
  );
}

export default App;
