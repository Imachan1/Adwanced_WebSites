// import React from "react";
// import {Row, Col, Container} from "react-bootstrap";

// function Checkout(){
//     return(    
//         <Container>
//             <form>
//                 <Row>
//                     <Col xs={12}>
//                         <h1>Witamy przy kasie</h1>
//                         <h2>Prosze podac dane do wysylki: </h2>
//                     </Col>
//                 </Row>
//                 <Row>
//                     <Col xs={12} md={6} lg={4}>
//                         <p>Imie:</p> <input type="text" name="imie" />
//                         <p>Nazwisko:</p> <input type="text" name="nazwisko" />
//                     </Col>
//                 </Row>
//             </form>
//         </Container>
//     );
// }

// export default Checkout;