export const destinations = [
  {
    id: 1,
    name: 'Kraków',
    image: '',
    fullPrice: 200,
    accommodation: 100,
    transportOwn: 0,
    onlyAccommodation: 50
  },
  {
    id: 2,
    name: 'Gdańsk',
    image: '',
    fullPrice: 250,
    accommodation: 120,
    transportOwn: 0,
    onlyAccommodation: 60
  },
  {
    id: 3,
    name: 'Wrocław',
    image: '',
    fullPrice: 220,
    accommodation: 110,
    transportOwn: 0,
    onlyAccommodation: 55
  }
];
