import React, { useState } from 'react';
import './App.css';

function App() {
  const destinations = [
    {
      id: 1,
      name: 'Kraków',
      image: '',
      fullPrice: 200,
      accommodation: 100,
      transportOwn: 0,
      onlyAccommodation: 50
    },
    {
      id: 2,
      name: 'Gdańsk',
      image: '',
      fullPrice: 250,
      accommodation: 120,
      transportOwn: 0,
      onlyAccommodation: 60
    },
    {
      id: 3,
      name: 'Wrocław',
      image: '',
      fullPrice: 220,
      accommodation: 110,
      transportOwn: 0,
      onlyAccommodation: 55
    }
  ];

  const [selectedPlace, setSelectedPlace] = useState('');

  const [numberOfPeople, setNumberOfPeople] = useState('');

  const [hasOwnTransport, setHasOwnTransport] = useState(false);

  const [accommodation, setAccommodation] = useState('');

  const [warnings, setWarnings] = useState('');

  const [email, setEmail] = useState('');

  const getSelectedDestination = () => {
    return destinations.find(dest => dest.id === parseInt(selectedPlace)) || {};
  };

  const calculateTotalPrice = () => {
    if (!selectedPlace || !numberOfPeople) {
      return 0;
    }

    const dest = getSelectedDestination();
    const people = parseInt(numberOfPeople);

    if (hasOwnTransport) {
      return 0;
    }

    return (dest.fullPrice * people) + (2 * dest.accommodation * people);
  };

  const isFormValid = () => {
    return (
      selectedPlace && 
      numberOfPeople && 
      parseInt(numberOfPeople) > 0 &&
      email && 
      email.includes('@')
    );
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!isFormValid()) {
      alert('Proszę wypełnić wszystkie pola poprawnie!');
      return;
    }

    const dest = getSelectedDestination();
    const totalPrice = calculateTotalPrice();

    const summary = `
 PODSUMOWANIE ZAMÓWIENIA 

MIEJSCE: ${dest.name}
LICZBA OSÓB: ${numberOfPeople}
WŁASNY TRANSPORT: ${hasOwnTransport ? 'TAK' : 'NIE'}
CENA CAŁKOWITA: ${totalPrice} zł
${warnings ? `UWAGI: ${warnings}` : ''}
KONTAKT: ${email}
    `;

    alert(summary);

    resetForm();
  };

  const resetForm = () => {
    setSelectedPlace('');
    setNumberOfPeople('');
    setHasOwnTransport(false);
    setAccommodation('');
    setWarnings('');
    setEmail('');
  };

  return (
    <div className="container">
      <h1>Zapraszamy na wycieczkę Twoich marzeń!</h1>
      
      <form onSubmit={handleSubmit} className="form">
        <div className="section">
          <label htmlFor="destination">Miejsce prosze wybrac z listy:</label>
          <select
            id="destination"
            value={selectedPlace}
            onChange={(e) => setSelectedPlace(e.target.value)}
            className="dropdown"
          >
            <option value="">-- Wybierz miejsce --</option>
            {destinations.map(dest => (
              <option key={dest.id} value={dest.id.toString()}>
                {dest.image} {dest.name}
              </option>
            ))}
          </select>
        </div>

        <div className="section">
          <label htmlFor="people">Ilość osób:</label>
          <input
            id="people"
            type="number"
            min="1"
            max="100"
            value={numberOfPeople}
            onChange={(e) => setNumberOfPeople(e.target.value)}
            placeholder="Wpisz liczbę"
          />
        </div>

        <div className="section">
          <label className="checkbox-label">
            <input
              type="checkbox"
              checked={hasOwnTransport}
              onChange={(e) => setHasOwnTransport(e.target.checked)}
            />
            Mam swój transport
          </label>
        </div>

        <div className="section">
          <label>Prosze zaznaczyc sposób wyzwienia:</label>
          <div className="radio-group">
            <label className="radio-label">
              <input
                type="radio"
                name="food"
                value="own-food"
                onChange={(e) => setAccommodation(e.target.value)}
              />
              własne
            </label>
            <label className="radio-label">
              <input
                type="radio"
                name="food"
                value="sniadania"
                onChange={(e) => setAccommodation(e.target.value)}
              />
              sniadania
            </label>
            <label className="radio-label">
              <input
                type="radio"
                name="food"
                value="pełne"
                onChange={(e) => setAccommodation(e.target.value)}
              />
              pełne
            </label>
          </div>
        </div>

        <div className="section">
          <label htmlFor="warnings">Uwagi do organizatora:</label>
          <textarea
            id="warnings"
            value={warnings}
            onChange={(e) => setWarnings(e.target.value)}
            placeholder="Wpisz ewentualne uwagi lub wymagania specjalne"
            rows="4"
          />
        </div>

        <div className="section">
          <label htmlFor="email">Adres do wysłania oferty:</label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Twój adres e-mail"
          />
        </div>

        {selectedPlace && (
          <div className="summary">
            <h3>Dane do wysyłania:</h3>
            <ol>
              <li>miejsce: {getSelectedDestination().name}</li>
              <li>ilość osób: {numberOfPeople || '?'}</li>
              <li>transport: {hasOwnTransport ? 'Własny transport' : 'Transport organizatora'}</li>
              <li>wyżywienie: {accommodation || '?'}</li>
              <li>uwagi: {warnings || 'brak'}</li>
              <li>adres e-mail: {email || '?'}</li>
              <li className="price">
                CENA CAŁKOWITA: {calculateTotalPrice()} zł
              </li>
            </ol>
          </div>
        )}

        <button 
          type="submit" 
          className="submit-btn"
          disabled={!isFormValid()}
        >
          Wyślij podsumowanie
        </button>
      </form>
    </div>
  );
}

export default App;
