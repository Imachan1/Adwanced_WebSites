import { destinations } from './data';

export const getSelectedDestination = (selectedPlace) => {
  return destinations.find(dest => dest.id === parseInt(selectedPlace)) || {};
};

export const calculateTotalPrice = (selectedPlace, numberOfPeople, hasOwnTransport) => {
  if (!selectedPlace || !numberOfPeople) {
    return 0;
  }

  const dest = getSelectedDestination(selectedPlace);
  const people = parseInt(numberOfPeople);

  if (hasOwnTransport) {
    return 0;
  }

  return (dest.fullPrice * people) + (2 * dest.accommodation * people);
};

export const isFormValid = (selectedPlace, numberOfPeople, email) => {
  return (
    selectedPlace && 
    numberOfPeople && 
    parseInt(numberOfPeople) > 0 &&
    email && 
    email.includes('@')
  );
};

export const generateSummary = (dest, numberOfPeople, hasOwnTransport, totalPrice, warnings, email) => {
  return `
=== PODSUMOWANIE ZAMÓWIENIA ===

MIEJSCE: ${dest.name}
LICZBA OSÓB: ${numberOfPeople}
WŁASNY TRANSPORT: ${hasOwnTransport ? 'TAK' : 'NIE'}
CENA CAŁKOWITA: ${totalPrice} zł
${warnings ? `UWAGI: ${warnings}` : ''}
KONTAKT: ${email}
  `;
};
